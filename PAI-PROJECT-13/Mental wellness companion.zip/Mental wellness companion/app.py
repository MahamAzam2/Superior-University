from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///wellness.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'

# Models - Updated to use DateTime instead of Date
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True, nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    journals = db.relationship('Journal', backref='author', lazy=True)
    moods = db.relationship('Mood', backref='user', lazy=True)

class Journal(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    content = db.Column(db.Text, nullable=False)
    # Changed from Date to DateTime
    date = db.Column(db.DateTime, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)

class Mood(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    score = db.Column(db.Integer, nullable=False)
    notes = db.Column(db.Text)
    # Changed from Date to DateTime
    date = db.Column(db.DateTime, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        
        # Check if email already exists
        existing_user = User.query.filter_by(email=email).first()
        if existing_user:
            flash('Email already registered. Please use a different email or login.')
            return redirect(url_for('register'))
        
        # Create new user
        hashed_password = generate_password_hash(password, method='pbkdf2:sha256')
        new_user = User(username=username, email=email, password=hashed_password)
        
        try:
            db.session.add(new_user)
            db.session.commit()
            flash('Registration successful! Please login.')
            return redirect(url_for('login'))
        except Exception as e:
            db.session.rollback()
            flash(f'Error during registration: {str(e)}')
    
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        
        user = User.query.filter_by(email=email).first()
        
        if user and check_password_hash(user.password, password):
            login_user(user)
            return redirect(url_for('dashboard'))
        else:
            flash('Login failed. Please check your email and password.')
    
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))

@app.route('/dashboard')
@login_required
def dashboard():
    now = datetime.now()
    
    # Get recent journals - order by date
    recent_journals = Journal.query.filter_by(user_id=current_user.id).order_by(Journal.date.desc()).limit(3).all()
    
    # Get mood data for chart - order by date
    moods = Mood.query.filter_by(user_id=current_user.id).order_by(Mood.date.desc()).limit(7).all()
    
    # Format journals for template
    formatted_journals = []
    for journal in recent_journals:
        # Simple sentiment analysis based on content
        sentiment = "neutral"
        if "happy" in journal.content.lower() or "good" in journal.content.lower():
            sentiment = "happy"
        elif "sad" in journal.content.lower() or "bad" in journal.content.lower():
            sentiment = "sad"
        elif "anxious" in journal.content.lower() or "worry" in journal.content.lower():
            sentiment = "anxious"
        elif "content" in journal.content.lower() or "peaceful" in journal.content.lower():
            sentiment = "content"
        
        formatted_journals.append({
            'content': journal.content,
            'date': journal.date,
            'emotion': sentiment
        })
    
    # Create mood chart data
    mood_dates = []
    mood_scores = []
    
    for mood in moods:
        mood_dates.append(mood.date.strftime('%b %d'))
        mood_scores.append(mood.score)
    
    # Reverse for chronological order
    mood_dates = mood_dates[::-1]
    mood_scores = mood_scores[::-1]
    
    return render_template('dashboard.html', 
                          now=now, 
                          recent_journals=formatted_journals,
                          mood_dates=mood_dates,
                          mood_scores=mood_scores)

@app.route('/journal', methods=['GET', 'POST'])
@login_required
def journal():
    now = datetime.now()
    
    if request.method == 'POST':
        content = request.form.get('content')
        
        if content:
            try:
                # Create new journal entry with current datetime
                new_entry = Journal(content=content, date=now, user_id=current_user.id)
                db.session.add(new_entry)
                db.session.commit()
                flash('Journal entry saved!')
            except Exception as e:
                db.session.rollback()
                flash(f'Error saving journal entry: {str(e)}')
    
    # Get journal entries - order by date
    entries = Journal.query.filter_by(user_id=current_user.id).order_by(Journal.date.desc()).all()
    
    # Format journals for template
    formatted_journals = []
    for entry in entries:
        # Determine emotion from content
        emotion = "neutral"
        sentiment_score = 0
        
        # Simple keyword-based sentiment analysis
        if "happy" in entry.content.lower() or "good" in entry.content.lower() or "joy" in entry.content.lower():
            emotion = "happy"
            sentiment_score = 0.7
        elif "sad" in entry.content.lower() or "bad" in entry.content.lower() or "depressed" in entry.content.lower():
            emotion = "sad"
            sentiment_score = -0.7
        elif "anxious" in entry.content.lower() or "worry" in entry.content.lower() or "nervous" in entry.content.lower():
            emotion = "anxious"
            sentiment_score = -0.5
        elif "content" in entry.content.lower() or "peaceful" in entry.content.lower() or "calm" in entry.content.lower():
            emotion = "content"
            sentiment_score = 0.5
        
        formatted_journals.append({
            'content': entry.content,
            'date': entry.date,
            'emotion': emotion,
            'sentiment_score': sentiment_score
        })
    
    return render_template('journal.html', journals=formatted_journals, now=now)

@app.route('/mood-tracker', methods=['GET', 'POST'])
@login_required
def mood_tracker():
    now = datetime.now()
    
    if request.method == 'POST':
        score = request.form.get('score')
        notes = request.form.get('notes')
        
        if score:
            try:
                # Create new mood entry with current datetime
                new_mood = Mood(score=int(score), notes=notes, date=now, user_id=current_user.id)
                db.session.add(new_mood)
                db.session.commit()
                flash('Mood recorded!')
            except Exception as e:
                db.session.rollback()
                flash(f'Error recording mood: {str(e)}')
    
    # Get mood entries - order by date
    moods = Mood.query.filter_by(user_id=current_user.id).order_by(Mood.date.desc()).all()
    
    # Format moods for template
    formatted_moods = []
    dates = []
    scores = []
    
    for mood in moods:
        emoji = "😐"  # Default neutral emoji
        if mood.score >= 9:
            emoji = "🤩"
        elif mood.score >= 7:
            emoji = "😁"
        elif mood.score >= 6:
            emoji = "😊"
        elif mood.score >= 5:
            emoji = "🙂"
        elif mood.score >= 4:
            emoji = "😐"
        elif mood.score >= 3:
            emoji = "😕"
        elif mood.score >= 2:
            emoji = "😔"
        else:
            emoji = "😢"
            
        formatted_moods.append({
            'score': mood.score,
            'notes': mood.notes,
            'date': mood.date,
            'emoji': emoji
        })
        
        # Add to chart data
        dates.append(mood.date.strftime('%b %d'))
        scores.append(mood.score)
    
    # Reverse for chronological order in chart
    dates = dates[::-1]
    scores = scores[::-1]
    
    return render_template('mood_tracker.html', moods=formatted_moods, dates=dates, scores=scores, now=now)

@app.route('/chatbot')
@login_required
def chatbot():
    now = datetime.now()
    return render_template('chatbot.html', now=now)

@app.route('/meditation')
@login_required
def meditation():
    now = datetime.now()
    return render_template('meditation.html', now=now)

@app.route('/api/chat', methods=['POST'])
@login_required
def chat_api():
    data = request.json
    user_message = data.get('message', '')
    
    # Simple response logic based on keywords
    response = "I'm here to listen. Can you tell me more about how you're feeling?"
    
    if 'anxious' in user_message.lower() or 'anxiety' in user_message.lower():
        response = "It sounds like you're feeling anxious. Try taking a few deep breaths. Remember that anxiety is temporary and will pass."
    elif 'sad' in user_message.lower() or 'depressed' in user_message.lower():
        response = "I'm sorry to hear you're feeling down. Remember that it's okay to feel sad sometimes. Would you like to try a mood-lifting activity?"
    elif 'stress' in user_message.lower() or 'stressed' in user_message.lower():
        response = "Stress can be challenging. Have you tried any relaxation techniques like deep breathing or meditation? Our meditation section has some helpful exercises."
    elif 'happy' in user_message.lower() or 'good' in user_message.lower():
        response = "I'm glad to hear you're feeling positive! What's contributing to your good mood today?"
    elif 'meditation' in user_message.lower():
        response = "Meditation is a great practice for mental wellness. You can find guided meditations in our Meditation section. Would you like to try a breathing exercise?"
    
    return jsonify({'response': response})

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
